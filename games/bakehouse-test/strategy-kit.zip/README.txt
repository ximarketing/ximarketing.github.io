Bakehouse student strategy v1 / 烘焙合成赛学生策略 v1

Requires Node.js 20 or newer. No packages or network are required.
使用 Node.js 20 或更高版本，无需安装依赖。解压后在本目录运行：
node evaluate.mjs example-strategy.mjs 1001 1002 1003

Edit or replace example-strategy.mjs. The command prints one final score per seed.
用自己的策略替换示例，可在命令末尾追加任意多个练习种子。每局输出终局分数和投放数。

Upload the same standalone .js or .mjs file in the student's Practice or Competition page.
同一份 .js 或 .mjs 单文件可在学生页「自由练习」和「加入比赛」使用。
Export choose({version,board,current,next}) and return a finite horizontal position 0–520.
board objects contain l (tier), r (radius), x/y (center), vx/vy (velocity).
The board is 520×680; downward is positive y. The current and next tiers are visible.
只用当前棋盘、当前点心和下一块点心。横向坐标 0 至 520，纵向向下为正值。
Browser decisions have a 5-second budget. Bundle any trained weights in the file.
浏览器每步限时 5 秒。模型参数须包含在单文件中，不能依赖网络请求或外部包。
For consistent replay after reconnecting, use a deterministic function of the supplied state.
想在刷新或重连后保持行为一致，请用当前输入决定落点。
