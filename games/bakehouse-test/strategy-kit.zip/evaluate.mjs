import {simulateDrop} from './engine.mjs';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const [policy='example-strategy.mjs',...seeds]=process.argv.slice(2);
for(const seed of seeds.length?seeds:['1001','1002','1003']){
  let rng=Number(seed);
  if(!Number.isInteger(rng)||rng<1||rng>4294967295)throw Error('Seed must be an integer from 1 to 4294967295.');
  function draw(){rng^=rng<<13;rng^=rng>>>17;rng^=rng<<5;rng>>>=0;return 1+rng%4;}
  const moduleURL=pathToFileURL(resolve(policy));
  moduleURL.searchParams.set('run',seed+':'+performance.now());
  const {choose}=await import(moduleURL);
  let board=[],current=draw(),next=draw(),score=0,drops=0;
  while(true){
    const x=await choose({version:1,board:structuredClone(board),current,next});
    if(!Number.isFinite(x)||x<0||x>520)throw Error('choose must return a position in [0,520].');
    const result=simulateDrop(board,current,x);board=result.board;score+=result.points;drops++;
    if(result.dead)break;
    current=next;next=draw();
  }
  console.log(JSON.stringify({seed:Number(seed),drops,score}));
}
